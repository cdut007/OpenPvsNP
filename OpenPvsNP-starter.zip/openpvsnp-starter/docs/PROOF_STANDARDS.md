# Mathematical proof standards

## Target statement

A direct route to `P = NP` is a deterministic algorithm deciding 3-SAT in polynomial worst-case time. Fix an encoding of 3-CNF instances as finite bit strings. Let `n` be the encoding length. A successful algorithm must satisfy, for all valid encoded instances `x`:

1. It halts.
2. It outputs `SAT` exactly when the encoded formula is satisfiable, and `UNSAT` otherwise.
3. Its running time on the chosen standard deterministic machine model is at most `c (n + 1)^k` for fixed constants `c > 0` and `k >= 0` independent of the input.

A complete proof of these properties, together with the standard NP-completeness of 3-SAT under polynomial-time many-one reductions, implies `P = NP`.

## Required specification

Every algorithmic claim must state:

- exact syntax and encoding of instances, including how variable indices and clause lists are represented;
- computational model (for example, a deterministic multi-tape Turing machine) and what counts as one step;
- correctness for every valid input, not only tested instances;
- termination for every valid input;
- a worst-case time bound in the bit-length of the input;
- the fixed constants and exponent in the polynomial bound;
- cost of preprocessing, reductions, data structures, arithmetic, memory access, and output construction;
- whether any advice, oracle, randomness, unbounded integer operation, non-uniformity, or promise is used.

## Frequent invalid inferences

- Fast behavior on all tested inputs does not establish a polynomial worst-case bound.
- A branching algorithm is not polynomial unless the total number of branches and the work per branch are bounded by one fixed polynomial for all inputs.
- A recurrence is not a proof until all base cases and the asymptotic solution are justified.
- A data structure operation is not constant time unless the chosen model and bit complexity justify it.
- A proof for a restricted input family does not establish a result for all 3-SAT instances.
- A probabilistic algorithm does not establish deterministic `P = NP` unless derandomization is proved.
- Showing that a particular proof strategy fails does not establish `P != NP`.
- A Lean theorem proves only its formal statement. The formal statement must be shown to encode the intended complexity-theoretic claim.

## Formalization policy

Lean is used to check formal derivations. The project pins a toolchain. Do not add `sorry`, `admit`, unsound axioms, `unsafe` shortcuts, or custom axioms that assume the target theorem. If an axiom or imported theorem is necessary, list it, identify its source, and explain whether it is already an accepted theorem or an assumption.

A successful build is necessary for a Lean artifact but not sufficient for mathematical acceptance. Reviewers must inspect the theorem statement, imports, axioms, dependencies, and any use of code generation or metaprogramming.

## Negative results

A refutation must identify a specific false statement, provide a counterexample or a rigorous argument, and distinguish refuting a candidate algorithm from proving a separation such as `P != NP`.
