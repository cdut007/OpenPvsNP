# Initial research roadmap

## Track A — formal foundations

Define a concrete encoding of 3-CNF formulas, literal and clause semantics, satisfying assignments, input length, deterministic machines, and polynomial time. Prove basic representation lemmas before attempting the target statement.

## Track B — complexity-theory bridge

Formalize or document the reduction-based implication: if 3-SAT is decidable in deterministic polynomial time, then every language in NP is, hence `P = NP`. Keep the theorem statement explicit about reduction overhead and input-length blow-up.

## Track C — candidate algorithms

Any proposed deterministic 3-SAT algorithm must have a complete description, correctness proof, and worst-case bit-complexity analysis. Search adversarially for families that trigger worst-case behavior.

## Track D — barrier and literature map

Document known limitations of proof techniques (including relativization, natural proofs, and algebrization) with primary references and precise statements. These are barriers to classes of techniques, not proofs that P vs NP is unresolvable.

## Track E — adversarial review

Independently review every claimed lemma or algorithm. Assign a different agent/model to search for counterexamples and hidden assumptions before a positive result is promoted.

## Milestones

1. Reproducible definitions and Lean build.
2. A reviewed formal statement of the 3-SAT-to-P=NP bridge.
3. A useful public literature map and proof-attempt archive.
4. Candidate algorithms and audits, each with precise complexity accounting.
5. External expert review for any complete resolution candidate.
