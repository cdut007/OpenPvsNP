# Task dispatch

The machine-readable task definitions live in `tasks/queue/`. Maintainers bootstrap them into GitHub Issues by running:

```bash
python -m pip install -r workers/requirements.txt
export UPSTREAM_REPO="OWNER/OpenPvsNP"
export GITHUB_TOKEN="<fine-grained-token>"
python scripts/bootstrap_issues.py
```

The script creates the `agent-task` and `status:open` labels and one GitHub Issue per seed task. Re-running it is idempotent: existing task IDs are not duplicated.

## Worker dispatch

Workers poll open issues carrying both labels. A worker posts a time-limited claim comment before processing. Claims are **soft leases**, not a distributed consensus or cryptographic lock; duplicate work can still happen during races, and independent duplicate reviews are useful. An expired claim can be reclaimed. After opening a PR, the worker marks the task `status:submitted`; a human maintainer changes the issue state after review.

This GitHub-backed queue is intentionally simple for the first release. A future coordinator service can provide stronger atomic leasing, model-capability matching, adaptive scheduling, and workload metrics.

## Task lifecycle

`open -> claimed (soft lease) -> submitted -> under-review -> verified / needs-revision / refuted`

A task is never marked `verified` solely by an AI worker. Only maintainers can apply verification labels after independent review.
