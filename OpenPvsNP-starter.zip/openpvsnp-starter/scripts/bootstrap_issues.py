from __future__ import annotations

import json
import os
from pathlib import Path
import requests

API = "https://api.github.com"


def main() -> None:
    repo = os.environ["UPSTREAM_REPO"]
    token = os.environ["GITHUB_TOKEN"]
    if "/" not in repo:
        raise SystemExit("UPSTREAM_REPO must be owner/name")
    session = requests.Session()
    session.headers.update({
        "Authorization": f"Bearer {token}",
        "Accept": "application/vnd.github+json",
        "X-GitHub-Api-Version": "2022-11-28",
        "User-Agent": "OpenPvsNP-bootstrap/0.1",
    })

    def call(method: str, path: str, **kwargs):
        r = session.request(method, f"{API}{path}", timeout=45, **kwargs)
        if not r.ok:
            raise RuntimeError(f"{method} {path}: HTTP {r.status_code}: {r.text[:1000]}")
        return r.json() if r.content else None

    labels = {x["name"] for x in call("GET", f"/repos/{repo}/labels?per_page=100")}
    for name, color, description in [
        ("agent-task", "1D76DB", "A task available to autonomous research workers"),
        ("status:open", "0E8A16", "Open for worker claims"),
        ("status:submitted", "FBCA04", "A worker submitted a PR; awaiting human review"),
        ("status:under-review", "5319E7", "Under human review"),
        ("status:verified", "0E8A16", "Specific claim independently verified by maintainers"),
        ("status:needs-revision", "D93F0B", "Submission requires revision"),
    ]:
        if name not in labels:
            call("POST", f"/repos/{repo}/labels", json={"name": name, "color": color, "description": description})
            print(f"Created label: {name}")

    existing = set()
    page = 1
    while page <= 10:
        issues = call("GET", f"/repos/{repo}/issues?state=all&per_page=100&page={page}")
        if not issues:
            break
        for issue in issues:
            if "pull_request" not in issue:
                existing.add(issue.get("title", ""))
        if len(issues) < 100:
            break
        page += 1

    for task_path in sorted(Path("tasks/queue").glob("*.json")):
        task = json.loads(task_path.read_text(encoding="utf-8"))
        title = f"[{task['task_id']}] {task['title']}"
        if title in existing:
            print(f"Already exists: {title}")
            continue
        body = (
            f"## Task\n\n{task['description']}\n\n"
            f"### Objective\n\n{task['objective']}\n\n"
            f"### Expected evidence\n\n" + "\n".join(f"- {x}" for x in task["expected_evidence"]) + "\n\n"
            f"### Acceptance criteria\n\n" + "\n".join(f"- [ ] {x}" for x in task["acceptance_criteria"]) + "\n\n"
            f"Machine-readable task: `tasks/queue/{task['task_id']}.json`\n\n"
            "This is an open research task, not a claim that a solution exists. See `AGENTS.md` and `docs/PROOF_STANDARDS.md`."
        )
        issue = call("POST", f"/repos/{repo}/issues", json={"title": title, "body": body, "labels": ["agent-task", "status:open"]})
        print(f"Created {title}: {issue['html_url']}")


if __name__ == "__main__":
    main()
