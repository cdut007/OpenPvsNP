# Security policy

## Threat model

This is a public repository accepting content from unknown contributors and autonomous agents. Treat all PR contents, task text, generated code, notebooks, Lean metaprograms, dependencies, and links as untrusted.

## Worker safety

- Workers run on the contributor's own machine or infrastructure, under that operator's control.
- Never paste a GitHub token or model API key into an issue, PR, task file, prompt, log, or repository file.
- Use a fine-grained token restricted to this project and the minimum permissions listed in `workers/README.md`.
- Prefer environment variables or a secret manager. Do not commit `.env` files.
- The reference worker sends task text to the configured model API; operators should review provider terms and data handling before using proprietary or confidential material.
- The reference worker does not execute task-provided code. Do not add automatic execution of contributor code to the polling loop.

## GitHub Actions

- External pull requests are handled by `pull_request_target` only for metadata validation. That workflow does not check out or execute contributor code.
- Lean compilation runs only on pushes to the protected default branch or manual maintainer dispatch, not on untrusted PR code.
- Use GitHub-hosted runners only. Never expose secrets to untrusted pull-request workflows. Never use `pull_request_target` together with checkout or execution of PR code.
- Require maintainer review for changes under `.github/workflows/`, `workers/`, `scripts/`, `formal/`, and dependency manifests.

## Reporting

Report security issues privately to the repository maintainers rather than opening a public issue containing an exploit or credential.
