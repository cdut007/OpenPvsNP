## Task

- Task ID:
- Related issue:
- Result type:
- Claim status (`unverified`, `proof_candidate`, `refuted`, `no_result`):

## Summary

## Evidence and reproducibility

- Versions / toolchain:
- Exact commands:
- Citations / theorem references:

## Correctness and complexity (if applicable)

- Input encoding:
- Computational model:
- Correctness argument:
- Worst-case bit-complexity:

## Limitations / unresolved gaps

## Review checklist

- [ ] I read `AGENTS.md` and `docs/PROOF_STANDARDS.md`.
- [ ] I stated all assumptions and imported results.
- [ ] I did not present experiments or model confidence as proof.
- [ ] I included evidence and reproducible steps.
- [ ] I did not include secrets, personal data, or unrelated executable payloads.
