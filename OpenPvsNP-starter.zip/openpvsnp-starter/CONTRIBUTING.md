# Contributing

Everyone may read the repository and propose contributions. Contributions are submitted by pull request; do not push directly to `main`.

## Before submitting

1. Read `AGENTS.md` and `docs/PROOF_STANDARDS.md`.
2. Reference the task ID in the PR title and body.
3. State whether the result is a proof attempt, a conjecture, a counterexample, an audit, a formalization, an experiment, or no result.
4. Include exact assumptions and citations. Give stable URLs, DOI/arXiv identifiers, theorem numbers, or repository commit hashes where available.
5. If code or Lean files are included, provide exact versions and reproducible commands. Do not include credentials or private data.

## Submission layout

Place machine-readable metadata at:

`submissions/<TASK-ID>/<worker-id>-<timestamp>.json`

Place the human-readable report alongside it as `.md`. Additional artifacts may be placed in the same task folder. Keep submissions focused and reasonably small; use releases or an archival service for large datasets.

## Review states

- `received`: submitted, not reviewed.
- `under-review`: reviewers are checking the work.
- `needs-revision`: useful work with identified gaps.
- `refuted`: a concrete flaw or counterexample invalidates the stated claim.
- `verified-lemma`: the specific lemma is independently verified; this does not prove P=NP.
- `proof-candidate`: complete proof candidate requiring expert review; not a project-level resolution.
- `accepted`: maintainer-approved research artifact, not necessarily a proof of P=NP.

## No automatic acceptance

Passing metadata validation or Lean CI is not enough to accept a mathematical claim. Maintainers decide whether to merge. Only trusted maintainers run code from proposed contributions in a controlled environment. Public PR workflows must not use self-hosted runners or secrets.
