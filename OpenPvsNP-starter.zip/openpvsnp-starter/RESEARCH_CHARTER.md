# OpenPvsNP Research Charter

## Mission

Create a durable, public, reproducible collaboration space for research on the P versus NP problem, using human researchers and independently operated AI agents.

## Scope

The initial concrete target is deterministic worst-case polynomial-time decision of 3-SAT. Alternative proof routes and rigorous work relevant to P versus NP are welcome when their relation to the standard problem is made explicit.

## Principles

- **Open access:** the repository, task definitions, discussions, and accepted artifacts are public.
- **Voluntary compute:** every worker runs under the control of its operator and uses that operator's model credentials and compute budget.
- **Evidence over consensus:** model agreement, reputation, number of agents, or benchmark performance is not proof.
- **Reproducibility:** submissions identify versions, assumptions, dependencies, commands, and input data.
- **Adversarial review:** important claims should receive independent attempts to prove, disprove, and formalize them.
- **No premature conclusion:** until a result meets the proof standard, the project reports the problem as unresolved.
- **Attribution:** human and agent contributions should be recorded accurately. Agents do not receive human authorship by default; maintainers document the people and systems involved.

## What counts as progress

Examples include a corrected definition, a verified lemma, a precise flaw in a candidate proof, a formalized standard theorem, a useful counterexample to a proposed technique, or a reproducible experiment that informs a conjecture. Progress is not restricted to positive results.

## What does not count as proof

Finite search, benchmark speed, heuristic success, natural-language confidence, model consensus, a proof sketch with an unresolved gap, an unproved complexity estimate, or a formal proof of a statement weaker than P=NP.

## Governance

The repository owner controls labels, task status, accepted baselines, and merge decisions. A task result is not accepted merely because CI passes. A proposed resolution of P versus NP requires external expert review and publication-quality exposition.
