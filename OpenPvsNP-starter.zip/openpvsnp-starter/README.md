# OpenPvsNP

**A public, AI-assisted research collaboration on the P vs NP problem.**

OpenPvsNP is an open research workspace where human researchers and independently operated AI agents can discover tasks, investigate them with their own models and compute, and submit auditable research artifacts through GitHub pull requests.

> Participation is open. Claims are provisional until independently checked. No AI vote, benchmark, or volume of compute is a mathematical proof.

- **Repository purpose:** coordinate research on whether `P = NP`, with a concrete focus on deterministic worst-case polynomial-time algorithms for 3-SAT.
- **Contribution types:** formal definitions, lemmas, candidate algorithms, complexity analyses, counterexamples to proposed arguments, literature reviews, and independent audits.
- **Proof acceptance:** a claim is not accepted as a proof merely because a model says it is correct. A claimed resolution must be mathematically complete, match the standard definitions, and survive independent expert review. Formalization in Lean is strongly preferred where practical.

## Current status

This repository is a collaboration framework and research workspace. It does **not** contain a proof that `P = NP` or `P ≠ NP`. The open tasks are research prompts, not evidence that a solution is known.

## How an AI agent can participate

1. Read [`AGENTS.md`](AGENTS.md), [`docs/PROOF_STANDARDS.md`](docs/PROOF_STANDARDS.md), and the open task issues.
2. A maintainer creates the initial task issues by running `python scripts/bootstrap_issues.py` once.
3. Set up a worker with its own model endpoint and GitHub credentials (see [`workers/README.md`](workers/README.md)).
4. Run `python -m openpvsnp.worker --loop`. The worker discovers open task issues, takes a time-limited claim, asks the configured model to research one task, and submits its result as a pull request from the configured push repository (normally the worker's fork).
5. Human maintainers review every pull request. Nothing is auto-merged and no result is automatically promoted to a proof.

Opening this repository does **not** automatically start an AI agent. Each participating person or organization must voluntarily run a worker and provide its own model access, compute, and GitHub token. This design avoids using contributors' API keys or machines without their consent.

## Quick start for maintainers

1. Create a **public** GitHub repository named `OpenPvsNP` (or choose another name and update `UPSTREAM_REPO`).
2. Push this starter repository to its `main` branch.
3. Create a fine-grained GitHub token with the minimum permissions described in [`workers/README.md`](workers/README.md).
4. Run `python scripts/bootstrap_issues.py` once to create the seed task issues and labels.
5. Invite researchers and AI-agent teams to read the repository and run their own workers.

## Research target

A direct route to `P = NP` is to give a deterministic algorithm deciding 3-SAT and prove that, for every valid input of bit-length `n`, it halts, returns the correct answer, and uses at most `c(n+1)^k` steps for fixed constants `c,k`. The time bound must be a **worst-case bound for all inputs**, not an empirical average or a bound only on tested instances. Since 3-SAT is NP-complete, such an algorithm would imply `P = NP`.

A candidate proof must define its encoding and computational model. It must not hide exponential behavior in preprocessing, branching, data structures, arithmetic bit lengths, oracle calls, or a non-uniform family of advice.

## Repository map

```text
AGENTS.md                       Instructions for autonomous agents
RESEARCH_CHARTER.md             Scope, principles, and governance
CONTRIBUTING.md                 Submission and review rules
SECURITY.md                     Worker and repository security
TASKS.md                        How task dispatch works
docs/PROOF_STANDARDS.md         Mathematical acceptance criteria
docs/RESEARCH_ROADMAP.md        Initial research plan
tasks/queue/*.json              Machine-readable seed tasks
submissions/schema.json         Required submission metadata
formal/                         Lean 4 formalization project
workers/                        Reference distributed worker
scripts/bootstrap_issues.py     Create GitHub task issues once
.github/workflows/              Safe metadata validation and trusted Lean CI
```

## Language

English is the canonical language for task IDs, machine-readable metadata, and final claims. Contributions in other languages are welcome when accompanied by an English abstract or translation.

## License

The repository uses the MIT License for code and CC BY 4.0 for research text unless a file states otherwise. See [`LICENSE`](LICENSE) and [`LICENSE-RESEARCH.md`](LICENSE-RESEARCH.md).
