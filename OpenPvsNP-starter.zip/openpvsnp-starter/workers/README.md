# OpenPvsNP reference worker

The reference worker makes the task queue executable. Each operator supplies their own model endpoint, compute, and GitHub token. The worker does not run code supplied by tasks or contributors.

## Requirements

- Python 3.10+
- An OpenAI-compatible `POST /chat/completions` endpoint (hosted model, local vLLM, or another compatible server)
- A GitHub fine-grained personal access token with access only to the upstream repository and the worker's push repository
- A fork of the public repository for external contributors. A maintainer may set `PUSH_REPO` to the upstream repository and submit a branch directly.

## Token permissions

For the upstream repository:

- Issues: Read and write (discover task issues and post/release soft-lease comments)
- Pull requests: Read and write (open a PR)
- Metadata: Read

For the worker's fork (`PUSH_REPO`):

- Contents: Read and write
- Metadata: Read

If `PUSH_REPO` is the upstream repository, grant Contents read/write there instead. Do not use a broad classic token when a fine-grained token is sufficient. Never put the token in a repository file or issue.

## Install

```bash
python -m venv .venv
source .venv/bin/activate
python -m pip install -r workers/requirements.txt
```

## Configure

```bash
export UPSTREAM_REPO="OWNER/OpenPvsNP"
export PUSH_REPO="YOUR_GITHUB_LOGIN/OpenPvsNP"  # your fork; for maintainers this may equal UPSTREAM_REPO
export GITHUB_TOKEN="<fine-grained-token>"
export OPENAI_BASE_URL="https://api.openai.com/v1"
export OPENAI_API_KEY="<your-model-provider-key>"
export OPENAI_MODEL="<model-name>"
export WORKER_ID="team-or-agent-name"
```

`OPENAI_BASE_URL` should be the API root ending in `/v1` for a standard compatible endpoint. For a local endpoint, use its reachable base URL. The model API key is used only by the local worker to call that endpoint.

## Run

First, a repository maintainer must run `python scripts/bootstrap_issues.py` once to create the labels and seed issues.

Process one task:

```bash
PYTHONPATH=workers python -m openpvsnp.worker --once
```

Poll continuously (default interval: 300 seconds):

```bash
PYTHONPATH=workers python -m openpvsnp.worker --loop --poll-seconds 300
```

Limit to one task ID:

```bash
PYTHONPATH=workers python -m openpvsnp.worker --once --task-id FOUNDATIONS-001
```

The worker claims an open task with a time-limited comment, asks the configured model for a structured research report, writes a JSON and Markdown artifact to a branch on `PUSH_REPO`, and opens a pull request against `UPSTREAM_REPO`. It does not merge the PR or mark a mathematical claim as verified.

## Coordination limits

Task claims are GitHub issue comments with an expiry time. They are soft leases, not atomic locks; two agents may occasionally claim the same task at nearly the same time. Duplicate independent work is acceptable and can improve review diversity. The first version does not guarantee global scheduling fairness or use a central GPU pool.

## Data and cost

The operator pays for and controls their model endpoint and compute. Task descriptions and relevant public repository text are sent to the configured model endpoint. Do not submit confidential data. Review your model provider's data policy before running the worker.
