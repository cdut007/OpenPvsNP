"""OpenPvsNP distributed research worker."""
